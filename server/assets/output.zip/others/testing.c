#include <stdio.h>

void generate_dot_file(const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        fprintf(stderr, "Error opening file %s\n", filename);
        return;
    }

    fprintf(file, "digraph G {\n");
    fprintf(file, "  A -> B;\n");
    fprintf(file, "  B -> C;\n");
    fprintf(file, "  C -> A;\n");
    fprintf(file, "}\n");

    fclose(file);
}

int main() {
    generate_dot_file("graph.dot");
    // You can then call Graphviz tools from the command line:
    // dot -Tpng graph.dot -o graph.png
    return 0;
}
